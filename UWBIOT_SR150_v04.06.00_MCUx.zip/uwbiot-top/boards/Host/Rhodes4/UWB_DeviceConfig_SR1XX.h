/*
 * Copyright 2018-2022 NXP.
 *
 * NXP Confidential. This software is owned or controlled by NXP and may only be
 * used strictly in accordance with the applicable license terms. By expressly
 * accepting such terms or by downloading,installing, activating and/or otherwise
 * using the software, you are agreeing that you have read,and that you agree to
 * comply with and are bound by, such license terms. If you do not agree to be
 * bound by the applicable license terms, then you may not retain, install, activate
 * or otherwise use the software.
 *
 */

/**************************************     UCI Packet Format    *****************************************
***********************************************************************************************************
|                         |                       |                               |
|----3----|--1---|---4----|------2----|-----6-----|-----8----|---------8----------|       L bytes
|                         |                       |                               |
-------------------------------------------------------------------------------------------------------------
|    MT   |  PBF |  GID   |     RFU   |    OID    |   RFU    | Payload Length (L) |      Payload
-------------------------------------------------------------------------------------------------------------
|                         |                       |                               |
|       OCTET 0           |      OCTET 1          |          OCTET 2-3            |      OCTET 4 - 4+L

***********************************************************************************************************
***********************************************************************************************************


*********************     UCI Packet Format for Extended Payload  (more than 255 bytes)  *****************
***********************************************************************************************************
|                         |                                           |                               |
|----3----|--1---|---4----|-----------1----------|---1----|-----6-----|-------8--------|------8-------|       L bytes
|                         |                                           |                               |
--------------------------------------------------------------------------------------------------------------------------
|    MT   |  PBF |  GID   |   UCI Extension Bit  |  RFU   |    OID    |  Extended Payload Length (L)  |      Payload
--------------------------------------------------------------------------------------------------------------------------
|                         |                                           |                               |
|       OCTET 0           |                  OCTET 1                  |            OCTET 2-3          |      OCTET 4 - 4+L

***********************************************************************************************************
**********************************************************************************************************/

/*
 * For NON single antenna variant
 */
#ifndef _UWB_DEVICECONFIG_RV4_SR1XX_H_
#define _UWB_DEVICECONFIG_RV4_SR1XX_H_

#include <stdint.h>
#include <uwb_board.h>
#include <phNxpUwbConfig.h>
#include <nxAntennaDefine.h>

/* Set to 0 in case you are using V3 Demonstrators,
 *
 * else set to 1 */
#define USE_NAKED_BOARD 0

/* SR160 Radar required Two TX reaming requires only One*/

#if UWBIOT_UWBD_SR160
#define TX_ANTENNA_ENTRIES 0x03
#define RX_ANTENNA_ENTRIES 0x04
#else
#define TX_ANTENNA_ENTRIES 0x01
#define RX_ANTENNA_ENTRIES 0x03
#endif //UWBIOT_UWBD_SR160

#define RX_ANTEENA_PAIR 0x02

/*
  * 0xE4 0x02 : DPD wakeup source : default value : 0x00
  * 0xE4 0x03 : WTX count config : default value : 20 (0x14)
  * 0xE4, 0x34: OEM XTAL start up time/clock request time
  * */

/* clang-format off */
const uint8_t phNxpUciHal_core_configs[] =
{
    0x12, 0x20, 0x04, 0x00, 0x0E, 0x03,
    0xE4, 0x02, 0x01, 0x00,
    0xE4, 0x03, 0x01, 0x14,
    0xE4, 0x34, 0x02, 0xE8, 0x03,
};

#if USE_NAKED_BOARD
#define GROUP_DELAY_CH5 (15078 - 42)
#define GROUP_DELAY_CH6 (15078 - 42)
#define GROUP_DELAY_CH8 (15078 - 50)
#define GROUP_DELAY_CH9 (15078 - 42)
#else
#define GROUP_DELAY_CH5 (15120)
#define GROUP_DELAY_CH6 (15120)
#define GROUP_DELAY_CH8 (15120)
#define GROUP_DELAY_CH9 (15120)
#endif

const uint8_t phNxpUciHal_rx_antennae_delay_calib_channel5[] =
{
/* Over All Length */ 4 + ( 3 + (1 + 3*AD_N_RX_ENTRIES(3))),
/* Set Calib */ 0x2F, 0x21,
/* Length */ 0,  3 + (1 + 3*AD_N_RX_ENTRIES(3)),
/* Channel */ AD_CALIB_CN(5),
/* GD Calib */ AD_CALIB_CMD_GD,
/* Length */ 1 + 3*AD_N_RX_ENTRIES(3),
/* N Entries */ AD_N_RX_ENTRIES(3),

/* GD Calib: Keep */ AD_RX_ID(1), AD_CALIB_GD(GROUP_DELAY_CH5),
/* GD Calib: Keep */ AD_RX_ID(2), AD_CALIB_GD(GROUP_DELAY_CH5),
/* GD Calib: Keep */ AD_RX_ID(3), AD_CALIB_GD(GROUP_DELAY_CH5),
/* GD Calib: Skip */ //  AD_RX_ID(4), AD_CALIB_GD(GROUP_DELAY_CH5),
/* GD Calib: Skip */ //  AD_RX_ID(5), AD_CALIB_GD(GROUP_DELAY_CH5),
/* GD Calib: Skip */ //  AD_RX_ID(6), AD_CALIB_GD(GROUP_DELAY_CH5),
/* GD Calib: Skip */ //  AD_RX_ID(7), AD_CALIB_GD(GROUP_DELAY_CH5),
/* GD Calib: Skip */ //  AD_RX_ID(8), AD_CALIB_GD(GROUP_DELAY_CH5),
/* GD Calib: Skip */ //  AD_RX_ID(9), AD_CALIB_GD(GROUP_DELAY_CH5),
/* GD Calib: Skip */ //  AD_RX_ID(10), AD_CALIB_GD(GROUP_DELAY_CH5),
/* GD Calib: Skip */ //  AD_RX_ID(11), AD_CALIB_GD(GROUP_DELAY_CH5),
/* GD Calib: Skip */ //  AD_RX_ID(12), AD_CALIB_GD(GROUP_DELAY_CH5),
};

const uint8_t phNxpUciHal_rx_antennae_delay_calib_channel9[] =
{
/* Over All Length */ 4 + ( 3 + (1 + 3*AD_N_RX_ENTRIES(3))),
/* Set Calib */ 0x2F, 0x21,
/* Length */ 0,  3 + (1 + 3*AD_N_RX_ENTRIES(3)),
/* Channel */ AD_CALIB_CN(9),
/* GD Calib */ AD_CALIB_CMD_GD,
/* Length */ 1 + 3*AD_N_RX_ENTRIES(3),
/* N Entries */ AD_N_RX_ENTRIES(3),

/* GD Calib: Keep */ AD_RX_ID(1), AD_CALIB_GD(GROUP_DELAY_CH9),
/* GD Calib: Keep */ AD_RX_ID(2), AD_CALIB_GD(GROUP_DELAY_CH9),
/* GD Calib: Keep */ AD_RX_ID(3), AD_CALIB_GD(GROUP_DELAY_CH9),
/* GD Calib: Skip */ //  AD_RX_ID(4), AD_CALIB_GD(GROUP_DELAY_CH9),
/* GD Calib: Skip */ //  AD_RX_ID(5), AD_CALIB_GD(GROUP_DELAY_CH9),
/* GD Calib: Skip */ //  AD_RX_ID(6), AD_CALIB_GD(GROUP_DELAY_CH9),
/* GD Calib: Skip */ //  AD_RX_ID(7), AD_CALIB_GD(GROUP_DELAY_CH9),
/* GD Calib: Skip */ //  AD_RX_ID(8), AD_CALIB_GD(GROUP_DELAY_CH9),
/* GD Calib: Skip */ //  AD_RX_ID(9), AD_CALIB_GD(GROUP_DELAY_CH9),
/* GD Calib: Skip */ //  AD_RX_ID(10), AD_CALIB_GD(GROUP_DELAY_CH9),
/* GD Calib: Skip */ //  AD_RX_ID(11), AD_CALIB_GD(GROUP_DELAY_CH9),
/* GD Calib: Skip */ //  AD_RX_ID(12), AD_CALIB_GD(GROUP_DELAY_CH9),
};

const uint8_t phNxpUciHal_rx_antennae_delay_calib_channel6[] =
{
/* Over All Length */ 4 + ( 3 + (1 + 3*AD_N_RX_ENTRIES(3))),
/* Set Calib */ 0x2F, 0x21,
/* Length */ 0,  3 + (1 + 3*AD_N_RX_ENTRIES(3)),
/* Channel */ AD_CALIB_CN(6),
/* GD Calib */ AD_CALIB_CMD_GD,
/* Length */ 1 + 3*AD_N_RX_ENTRIES(3),
/* N Entries */ AD_N_RX_ENTRIES(3),

/* GD Calib: Keep */ AD_RX_ID(1), AD_CALIB_GD(GROUP_DELAY_CH6),
/* GD Calib: Keep */ AD_RX_ID(2), AD_CALIB_GD(GROUP_DELAY_CH6),
/* GD Calib: Keep */ AD_RX_ID(3), AD_CALIB_GD(GROUP_DELAY_CH6),
/* GD Calib: Skip */ //  AD_RX_ID(4), AD_CALIB_GD(GROUP_DELAY_CH6),
/* GD Calib: Skip */ //  AD_RX_ID(5), AD_CALIB_GD(GROUP_DELAY_CH6),
/* GD Calib: Skip */ //  AD_RX_ID(6), AD_CALIB_GD(GROUP_DELAY_CH6),
/* GD Calib: Skip */ //  AD_RX_ID(7), AD_CALIB_GD(GROUP_DELAY_CH6),
/* GD Calib: Skip */ //  AD_RX_ID(8), AD_CALIB_GD(GROUP_DELAY_CH6),
/* GD Calib: Skip */ //  AD_RX_ID(9), AD_CALIB_GD(GROUP_DELAY_CH6),
/* GD Calib: Skip */ //  AD_RX_ID(10), AD_CALIB_GD(GROUP_DELAY_CH6),
/* GD Calib: Skip */ //  AD_RX_ID(11), AD_CALIB_GD(GROUP_DELAY_CH6),
/* GD Calib: Skip */ //  AD_RX_ID(12), AD_CALIB_GD(GROUP_DELAY_CH6),
};

const uint8_t phNxpUciHal_rx_antennae_delay_calib_channel8[] =
{
/* Over All Length */ 4 + ( 3 + (1 + 3*AD_N_RX_ENTRIES(3))),
/* Set Calib */ 0x2F, 0x21,
/* Length */ 0,  3 + (1 + 3*AD_N_RX_ENTRIES(3)),
/* Channel */ AD_CALIB_CN(8),
/* GD Calib */ AD_CALIB_CMD_GD,
/* Length */ 1 + 3*AD_N_RX_ENTRIES(3),
/* N Entries */ AD_N_RX_ENTRIES(3),

/* GD Calib: Keep */ AD_RX_ID(1), AD_CALIB_GD(GROUP_DELAY_CH8),
/* GD Calib: Keep */ AD_RX_ID(2), AD_CALIB_GD(GROUP_DELAY_CH8),
/* GD Calib: Keep */ AD_RX_ID(3), AD_CALIB_GD(GROUP_DELAY_CH8),
/* GD Calib: Skip */ //  AD_RX_ID(4), AD_CALIB_GD(GROUP_DELAY_CH8),
/* GD Calib: Skip */ //  AD_RX_ID(5), AD_CALIB_GD(GROUP_DELAY_CH8),
/* GD Calib: Skip */ //  AD_RX_ID(6), AD_CALIB_GD(GROUP_DELAY_CH8),
/* GD Calib: Skip */ //  AD_RX_ID(7), AD_CALIB_GD(GROUP_DELAY_CH8),
/* GD Calib: Skip */ //  AD_RX_ID(8), AD_CALIB_GD(GROUP_DELAY_CH8),
/* GD Calib: Skip */ //  AD_RX_ID(9), AD_CALIB_GD(GROUP_DELAY_CH8),
/* GD Calib: Skip */ //  AD_RX_ID(10), AD_CALIB_GD(GROUP_DELAY_CH8),
/* GD Calib: Skip */ //  AD_RX_ID(11), AD_CALIB_GD(GROUP_DELAY_CH8),
/* GD Calib: Skip */ //  AD_RX_ID(12), AD_CALIB_GD(GROUP_DELAY_CH8),
};

const uint8_t phNxpUciHal_core_antennadefs[] =
{
 /* Full length */ 4 + (1 + 3 + 3 + 3 +  ((1 + 6*AD_N_RX_ENTRIES(RX_ANTENNA_ENTRIES)) + (1 + 5*AD_N_TX_ENTRIES(TX_ANTENNA_ENTRIES)) + (1 + 6*AD_N_PAIR_ENTRIES(RX_ANTEENA_PAIR)))) ,
 /* Core set config */ 0x20, 0x04,
 /* Length */ 0x00, 1 + 3 + 3 + 3 +  ((1 + 6*AD_N_RX_ENTRIES(RX_ANTENNA_ENTRIES)) + (1 + 5*AD_N_TX_ENTRIES(TX_ANTENNA_ENTRIES)) + (1 + 6*AD_N_PAIR_ENTRIES(RX_ANTEENA_PAIR))) ,
 /* Num Configs */ 3,
AD_ANTENNA_RX_IDX_DEFINE_GPIO,
 (1 + 6*AD_N_RX_ENTRIES(RX_ANTENNA_ENTRIES)) , AD_N_RX_ENTRIES(RX_ANTENNA_ENTRIES),
#if UWBIOT_UWBD_SR160
    AD_RX_ID(1), AD_DEF_RX_PORT(0x01), AD_DEF_MASK(0x0002), AD_DEF_VAL(0x0002),
    AD_RX_ID(2), AD_DEF_RX_PORT(0x01), AD_DEF_MASK(0x0002), AD_DEF_VAL(0),
    AD_RX_ID(3), AD_DEF_RX_PORT(0x02), AD_DEF_MASK(0x0001), AD_DEF_VAL(0x0001),
    AD_RX_ID(4), AD_DEF_RX_PORT(0x02), AD_DEF_MASK(0x0001), AD_DEF_VAL(0x0),
#else
    // V AoA for Patch Array on V3 Demonstrator
    // Azimuth on the Naked RV4 board
    // Used for PCTT as well. EF2 High.
    AD_RX_ID(1), AD_DEF_RX_PORT(SR1XX_RX1_PORT), AD_DEF_MASK(kAD_GPIO_EF2), AD_DEF_VAL(kAD_GPIO_EF2),
    // H AoA for Patch Array on V3 Demonstrator.
    // NA for Naked RV4 board
    AD_RX_ID(2), AD_DEF_RX_PORT(SR1XX_RX1_PORT), AD_DEF_MASK(kAD_GPIO_EF2), AD_DEF_VAL(0),
    /* Common RX Pin for both H and V. Goes to TX/RX2 port of Helios  */
    AD_RX_ID(3), AD_DEF_RX_PORT(SR1XX_RX2_PORT), AD_DEF_MASK(kAD_GPIO_EF1), AD_DEF_VAL(kAD_GPIO_EF1),
#endif //UWBIOT_UWBD_SR160
    /* RX GPIO: Skip */ //  AD_RX_ID(5), AD_DEF_RX_PORT(SR1XX_RX_INVALID_PORT), AD_DEF_MASK(0x0000), AD_DEF_VAL(0x0000),
    /* RX GPIO: Skip */ //  AD_RX_ID(6), AD_DEF_RX_PORT(SR1XX_RX_INVALID_PORT), AD_DEF_MASK(0x0000), AD_DEF_VAL(0x0000),
    /* RX GPIO: Skip */ //  AD_RX_ID(7), AD_DEF_RX_PORT(SR1XX_RX_INVALID_PORT), AD_DEF_MASK(0x0000), AD_DEF_VAL(0x0000),
    /* RX GPIO: Skip */ //  AD_RX_ID(8), AD_DEF_RX_PORT(SR1XX_RX_INVALID_PORT), AD_DEF_MASK(0x0000), AD_DEF_VAL(0x0000),
    /* RX GPIO: Skip */ //  AD_RX_ID(9), AD_DEF_RX_PORT(SR1XX_RX_INVALID_PORT), AD_DEF_MASK(0x0000), AD_DEF_VAL(0x0000),
    /* RX GPIO: Skip */ //  AD_RX_ID(10), AD_DEF_RX_PORT(SR1XX_RX_INVALID_PORT), AD_DEF_MASK(0x0000), AD_DEF_VAL(0x0000),
    /* RX GPIO: Skip */ //  AD_RX_ID(11), AD_DEF_RX_PORT(SR1XX_RX_INVALID_PORT), AD_DEF_MASK(0x0000), AD_DEF_VAL(0x0000),
    /* RX GPIO: Skip */ //  AD_RX_ID(12), AD_DEF_RX_PORT(SR1XX_RX_INVALID_PORT), AD_DEF_MASK(0x0000), AD_DEF_VAL(0x0000),


AD_ANTENNA_TX_IDX_DEFINE,
 (1 + 5*AD_N_TX_ENTRIES(TX_ANTENNA_ENTRIES)) , AD_N_TX_ENTRIES(TX_ANTENNA_ENTRIES),
#if UWBIOT_UWBD_SR160
    /** 3 TX defines  are Required for Radar */
    /* TX-1 GPIO */  AD_TX_ID(1), AD_DEF_MASK(0x05), AD_DEF_VAL(0x00),
    /* TX-2 GPIO:*/  AD_TX_ID(2), AD_DEF_MASK(0x05), AD_DEF_VAL(0x0001),
    /* TX-3 GPIO:*/  AD_TX_ID(3), AD_DEF_MASK(0x05), AD_DEF_VAL(0x0005),
#else
    /* TX GPIO: Keep */ AD_TX_ID(1), AD_DEF_MASK(kAD_GPIO_EF1), AD_DEF_VAL(0),
#endif// UWBIOT_UWBD_SR160
    /* TX GPIO: Skip */ //  AD_TX_ID(3), AD_DEF_MASK(0x0000), AD_DEF_VAL(0x0000),
    /* TX GPIO: Skip */ //  AD_TX_ID(4), AD_DEF_MASK(0x0000), AD_DEF_VAL(0x0000),

AD_ANTENNAS_RX_PAIR_DEFINE,
 (1 + 6*AD_N_PAIR_ENTRIES(RX_ANTEENA_PAIR)) , AD_N_PAIR_ENTRIES(RX_ANTEENA_PAIR),

/* 2D-AoA */
#if USE_NAKED_BOARD
    /* RX Pair: H (Naked)   */ AD_AP_ID(1), AD_AP_RX1(1 /*EF2 High */), AD_AP_RX2(3), AD_AP_RX3(0), AD_AP_FOV(0x0000), // H
#else
    /* RX Pair: H (V3 Demo) */ AD_AP_ID(1), AD_AP_RX1(2 /*EF2 LOW */), AD_AP_RX2(3), AD_AP_RX3(0), AD_AP_FOV(0x0000), // H
#endif
#if UWBIOT_UWBD_SR160
    /* RX Pair: V           */ AD_AP_ID(2), AD_AP_RX1(2), AD_AP_RX2(4), AD_AP_RX3(0), AD_AP_FOV(0x0000), // V
#else
    /* RX Pair: V           */ AD_AP_ID(2), AD_AP_RX1(1), AD_AP_RX2(3), AD_AP_RX3(0), AD_AP_FOV(0x0000), // V
#endif //UWBIOT_UWBD_SR160
    /* RX Pair: Skip */ //  AD_AP_ID(3), AD_AP_RX1(0), AD_AP_RX2(0), AD_AP_FOV(0x0000),
    /* RX Pair: Skip */ //  AD_AP_ID(4), AD_AP_RX1(0), AD_AP_RX2(0), AD_AP_FOV(0x0000),
    /* RX Pair: Skip */ //  AD_AP_ID(5), AD_AP_RX1(0), AD_AP_RX2(0), AD_AP_FOV(0x0000),
    /* RX Pair: Skip */ //  AD_AP_ID(6), AD_AP_RX1(0), AD_AP_RX2(0), AD_AP_FOV(0x0000),
    /* RX Pair: Skip */ //  AD_AP_ID(7), AD_AP_RX1(0), AD_AP_RX2(0), AD_AP_FOV(0x0000),
    /* RX Pair: Skip */ //  AD_AP_ID(8), AD_AP_RX1(0), AD_AP_RX2(0), AD_AP_FOV(0x0000),
};

const uint8_t phNxpUciHal_rx_pair_1_ch_5_pdoa_calib[] = {
   /* Over All Length */ 4 + (5 + AD_CALIB_LEN_PDOA_CALIB),
   /* Set Calib */ 0x2F, 0x21,    // 0x11 (0001 0001) to be used without UCI Payload Extension and 0x91(1001 0001) to be used with UCI Payload Extension
   /* Length */ 0x00, 5 + AD_CALIB_LEN_PDOA_CALIB,
   /* Channel */ AD_CALIB_CN(5),
   /* pdoa calib */ AD_CALIB_CMD_PDOA_CALIB,
   2 + AD_CALIB_LEN_PDOA_CALIB,
   /* N Entries */ AD_N_PAIR_ENTRIES(1),
   /* RX Pair */ AD_AP_ID(1),
/*Pan -60,        -48,        -36,        -24,        -12,          0,        +12,        +24,        +36,        +48,        +60, */
   0x6F, 0xCE, 0xCD, 0xCE, 0x97, 0xD6, 0x19, 0xE1, 0xDD, 0xEF, 0xF9, 0x00, 0x88, 0x0F, 0x98, 0x1A, 0xC4, 0x24, 0x4C, 0x30, 0x83, 0x37,
   0xAF, 0xD1, 0xE0, 0xCF, 0xC1, 0xD4, 0x7F, 0xDF, 0xB7, 0xED, 0x21, 0xFD, 0x8B, 0x0B, 0xA6, 0x18, 0xED, 0x24, 0x2F, 0x2F, 0x61, 0x35,
   0x7C, 0xD1, 0x31, 0xD2, 0x8A, 0xD6, 0x81, 0xDF, 0xAB, 0xEC, 0x4F, 0xFC, 0x75, 0x0B, 0xC4, 0x18, 0x91, 0x23, 0x54, 0x2C, 0x1E, 0x34,
   0xAE, 0xCF, 0x6D, 0xD3, 0xDE, 0xD9, 0x5F, 0xE2, 0x9C, 0xED, 0xB3, 0xFB, 0xDE, 0x09, 0x63, 0x16, 0x1E, 0x21, 0xCD, 0x2B, 0x48, 0x35,
   0x9A, 0xCD, 0xB0, 0xD2, 0x2C, 0xDA, 0x24, 0xE3, 0xF4, 0xED, 0xDD, 0xFA, 0xCD, 0x08, 0x6C, 0x16, 0xE6, 0x22, 0xA9, 0x2E, 0x78, 0x37,
   0x97, 0xCC, 0xA8, 0xD1, 0xB6, 0xD8, 0x29, 0xE2, 0xB3, 0xEE, 0x89, 0xFE, 0xBE, 0x0E, 0xCB, 0x1C, 0xAC, 0x28, 0x71, 0x32, 0x43, 0x39,
   0xBE, 0xCB, 0xC0, 0xCF, 0xB8, 0xD6, 0x90, 0xE1, 0x13, 0xF1, 0xD4, 0x02, 0x22, 0x12, 0x48, 0x1E, 0xE6, 0x28, 0x1A, 0x32, 0x41, 0x39,
   0xB5, 0xCA, 0x3C, 0xCF, 0xF0, 0xD6, 0x39, 0xE4, 0xAC, 0xF4, 0xEE, 0x03, 0x74, 0x0F, 0xE0, 0x18, 0x4E, 0x23, 0xB2, 0x2F, 0x3A, 0x38,
   0xF0, 0xC7, 0x11, 0xD0, 0x9D, 0xD9, 0x87, 0xE6, 0xB9, 0xF5, 0x1D, 0x03, 0x38, 0x0C, 0xF2, 0x12, 0x64, 0x1C, 0x64, 0x2C, 0x2D, 0x36,
   0xBD, 0xC6, 0x8C, 0xCF, 0x0A, 0xDA, 0x37, 0xE7, 0x1D, 0xF5, 0x3B, 0x02, 0x58, 0x0B, 0x03, 0x10, 0x30, 0x19, 0xF2, 0x25, 0x7C, 0x2F,
   0x3E, 0xC8, 0xBC, 0xCD, 0x5C, 0xD9, 0x56, 0xE7, 0x0C, 0xF3, 0xE8, 0xFF, 0x77, 0x0A, 0xC5, 0x10, 0xDB, 0x17, 0x89, 0x1C, 0xE9, 0x32,
};

const uint8_t phNxpUciHal_rx_pair_1_ch_9_pdoa_calib[] = {
   /* Over All Length */ 4 + (5 + AD_CALIB_LEN_PDOA_CALIB),
   /* Set Calib */ 0x2F, 0x21,
   /* Length */ 0x00, 5 + AD_CALIB_LEN_PDOA_CALIB,
   /* Channel */ AD_CALIB_CN(9),
   /* pdoa calib */ AD_CALIB_CMD_PDOA_CALIB,
   2 + AD_CALIB_LEN_PDOA_CALIB,
   /* N Entries */ AD_N_PAIR_ENTRIES(1),
   /* RX Pair */ AD_AP_ID(1),
   /* Pan   -60,        -48,        -36,        -24,        -12,          0,        +12,        +24,        +36,        +48,        +60, */
         0xEF, 0xB7, 0x41, 0xC0, 0x67, 0xCD, 0xD3, 0xDD, 0x50, 0xF0, 0x5F, 0x00, 0x00, 0x0B, 0xBA, 0x15, 0x5F, 0x27, 0x80, 0x37, 0x9E, 0x41, /* Tilt: -60 */
         0x20, 0xB8, 0xB6, 0xBE, 0xF7, 0xCA, 0x13, 0xDD, 0x40, 0xEF, 0x94, 0xFE, 0x22, 0x0B, 0x82, 0x19, 0xDC, 0x29, 0x70, 0x37, 0x69, 0x40, /* Tilt: -48 */
         0x74, 0xBA, 0x29, 0xC1, 0x9C, 0xCB, 0xBE, 0xDB, 0xAC, 0xED, 0x23, 0xFE, 0x99, 0x0C, 0x96, 0x1B, 0x06, 0x2B, 0xE3, 0x37, 0xCD, 0x3F, /* Tilt: -36 */
         0xF2, 0xBB, 0x6E, 0xC2, 0x46, 0xCC, 0xFD, 0xDA, 0xCB, 0xEC, 0x08, 0xFF, 0xA3, 0x0F, 0x2D, 0x1F, 0x64, 0x2D, 0x89, 0x38, 0x67, 0x3F, /* Tilt: -24 */
         0xC3, 0xBC, 0xA9, 0xC2, 0xBB, 0xCC, 0x2A, 0xDC, 0x35, 0xEE, 0x18, 0x01, 0x9A, 0x11, 0x66, 0x20, 0xA4, 0x2D, 0x38, 0x38, 0x63, 0x3F, /* Tilt: -12 */
         0x91, 0xBD, 0xBE, 0xC3, 0x04, 0xCE, 0x1C, 0xDE, 0x27, 0xF0, 0x43, 0x01, 0xF1, 0x11, 0x4D, 0x22, 0xF0, 0x2F, 0x0F, 0x3A, 0x3B, 0x41, /* Tilt: 0 */
         0xF9, 0xBD, 0x94, 0xC4, 0xEB, 0xCD, 0x86, 0xDC, 0x53, 0xEF, 0x30, 0x01, 0xBB, 0x11, 0x3E, 0x23, 0xBB, 0x31, 0xAB, 0x3C, 0x67, 0x44, /* Tilt: 12 */
         0x77, 0xBD, 0x23, 0xC4, 0xCB, 0xCB, 0x22, 0xD8, 0x49, 0xEC, 0xC4, 0x02, 0xC0, 0x13, 0x1F, 0x23, 0x16, 0x32, 0x73, 0x3E, 0x9E, 0x45, /* Tilt: 24 */
         0x8F, 0xBB, 0x3D, 0xC2, 0x9B, 0xC9, 0xAB, 0xD5, 0xB5, 0xEA, 0x98, 0x03, 0x8A, 0x14, 0xD3, 0x21, 0x08, 0x30, 0x12, 0x3C, 0x40, 0x43, /* Tilt: 36 */
         0xD3, 0xBB, 0x03, 0xBF, 0xE8, 0xC6, 0x5E, 0xD5, 0x49, 0xEB, 0x87, 0x02, 0xCC, 0x13, 0xB1, 0x1D, 0x89, 0x29, 0x35, 0x38, 0x11, 0x48, /* Tilt: 48 */
         0x63, 0xBC, 0x54, 0xBE, 0x98, 0xC3, 0x81, 0xD6, 0x24, 0xEC, 0xA7, 0xFD, 0xEB, 0x0F, 0x44, 0x1C, 0x3D, 0x28, 0x97, 0x39, 0x6C, 0x47  /* Tilt: 60 */
};

const uint8_t phNxpUciHal_rx_pair_2_ch_5_pdoa_calib[] = {
   /* Over All Length */ 4 + (5 + AD_CALIB_LEN_PDOA_CALIB),
   /* Set Calib */ 0x2F, 0x21,
   /* Length */ 0x00, 5 + AD_CALIB_LEN_PDOA_CALIB,
   /* Channel */ AD_CALIB_CN(5),
   /* pdoa calib */ AD_CALIB_CMD_PDOA_CALIB,
   2 + AD_CALIB_LEN_PDOA_CALIB,
   /* N Entries */ AD_N_PAIR_ENTRIES(1),
   /* RX Pair */ AD_AP_ID(2),
   /* Tilt -60,        -48,        -36,        -24,        -12,          0,        +12,        +24,        +36,        +48,        +60, */
         0x25, 0xE5, 0x05, 0xE8, 0x9E, 0xEB, 0x0D, 0xF1, 0x66, 0xF7, 0xD4, 0xFD, 0xE1, 0x03, 0xF8, 0x07, 0x79, 0x0A, 0xE6, 0x0F, 0xFB, 0x0E, /* Pan: -60 */
         0xC2, 0xDC, 0x56, 0xDD, 0xE7, 0xE0, 0x58, 0xE8, 0x47, 0xF1, 0x15, 0xFC, 0xD3, 0x05, 0x08, 0x0E, 0xB1, 0x13, 0x56, 0x18, 0xC5, 0x17, /* Pan: -48 */
         0x22, 0xD3, 0x0F, 0xD6, 0xB3, 0xDA, 0x11, 0xE2, 0x6B, 0xEC, 0x7B, 0xFB, 0x82, 0x07, 0x70, 0x11, 0x93, 0x1B, 0xC3, 0x20, 0x3E, 0x21, /* Pan: -36 */
         0xB2, 0xCB, 0xA8, 0xD0, 0x88, 0xD7, 0x5D, 0xDE, 0x01, 0xE9, 0xB2, 0xFB, 0xB6, 0x08, 0x9A, 0x13, 0x42, 0x21, 0xBA, 0x29, 0x10, 0x31, /* Pan: -24 */
         0xD1, 0xC7, 0x17, 0xCD, 0x55, 0xD5, 0x6C, 0xDC, 0xAB, 0xE6, 0x2D, 0xFC, 0x65, 0x0A, 0x23, 0x16, 0x49, 0x25, 0xAF, 0x2F, 0xAA, 0x38, /* Pan: -12 */
         0x3A, 0xC7, 0xF4, 0xCB, 0xBE, 0xD3, 0x70, 0xDB, 0x90, 0xE5, 0xED, 0xFC, 0xA5, 0x0C, 0x88, 0x17, 0x98, 0x26, 0xF1, 0x31, 0xC6, 0x38, /* Pan: 0 */
         0x8E, 0xC8, 0xD1, 0xCC, 0xFA, 0xD3, 0x5B, 0xDB, 0xF7, 0xE5, 0xD5, 0xFD, 0x4F, 0x0E, 0xB1, 0x16, 0x59, 0x24, 0x6E, 0x32, 0x98, 0x35, /* Pan: 12 */
         0x6B, 0xCB, 0x85, 0xCF, 0xC7, 0xD5, 0x64, 0xDC, 0xB6, 0xE7, 0x3A, 0xFE, 0x6C, 0x0E, 0x3F, 0x14, 0x08, 0x1D, 0x92, 0x2B, 0xA8, 0x33, /* Pan: 24 */
         0xB5, 0xCF, 0x64, 0xD3, 0x6D, 0xD8, 0x58, 0xDE, 0xBA, 0xEA, 0xA7, 0xFE, 0xCD, 0x0D, 0xE4, 0x12, 0xD8, 0x14, 0xC7, 0x1D, 0xF3, 0x2E, /* Pan: 36 */
         0xE3, 0xD5, 0xF8, 0xD8, 0x6B, 0xDC, 0xCC, 0xE2, 0xFA, 0xEE, 0x00, 0xFF, 0x6A, 0x0C, 0xAD, 0x13, 0x7D, 0x16, 0x89, 0x18, 0x0C, 0x1C, /* Pan: 48 */
         0x93, 0xDC, 0xB9, 0xDE, 0x2C, 0xE2, 0x0A, 0xE9, 0x18, 0xF3, 0x84, 0xFE, 0x13, 0x09, 0x51, 0x11, 0xCF, 0x17, 0xDE, 0x16, 0xC7, 0x24  /* Pan: 60 */
};

const uint8_t phNxpUciHal_rx_pair_2_ch_9_pdoa_calib[] = {
   /* Over All Length */ 4 + (5 + AD_CALIB_LEN_PDOA_CALIB),
   /* Set Calib */ 0x2F, 0x21,
   /* Length */ 0x00, 5 + AD_CALIB_LEN_PDOA_CALIB,
   /* Channel */ AD_CALIB_CN(9),
   /* pdoa calib */ AD_CALIB_CMD_PDOA_CALIB,
   2 + AD_CALIB_LEN_PDOA_CALIB,
   /* N Entries */ AD_N_PAIR_ENTRIES(1),
   /* RX Pair */ AD_AP_ID(2),
   /* Tilt -60,        -48,        -36,        -24,        -12,          0,        +12,        +24,        +36,        +48,        +60, */
         0x7A, 0xD3, 0x8D, 0xD8, 0x12, 0xE0, 0xD7, 0xE9, 0x6F, 0xF4, 0x80, 0xFE, 0x26, 0x08, 0x10, 0x10, 0x74, 0x16, 0xC1, 0x1D, 0xE0, 0x20, /* Pan: -60 */
         0xFC, 0xCC, 0x21, 0xD2, 0x77, 0xD9, 0x1A, 0xE4, 0x8B, 0xF0, 0xE2, 0xFD, 0x17, 0x0C, 0xB9, 0x17, 0xB5, 0x1F, 0xE1, 0x26, 0xBF, 0x2D, /* Pan: -48 */
         0x8A, 0xC5, 0x97, 0xCC, 0x15, 0xD5, 0xE0, 0xDF, 0x53, 0xED, 0x23, 0xFD, 0xFD, 0x0E, 0x03, 0x1D, 0x60, 0x27, 0x8A, 0x2D, 0x55, 0x33, /* Pan: -36 */
         0x86, 0xBE, 0x82, 0xC6, 0xE4, 0xD0, 0xFD, 0xDC, 0xA7, 0xEB, 0xBE, 0xFC, 0xF0, 0x0F, 0xA4, 0x1F, 0x82, 0x2B, 0x2B, 0x32, 0x2C, 0x37, /* Pan: -24 */
         0x34, 0xBC, 0xFB, 0xC2, 0xA1, 0xCD, 0x9D, 0xDB, 0x2B, 0xEC, 0x2C, 0xFD, 0xC8, 0x0F, 0xE8, 0x21, 0x5D, 0x2F, 0xC7, 0x36, 0x66, 0x3D, /* Pan: -12 */
         0x03, 0xBD, 0xB5, 0xC2, 0x7E, 0xCC, 0x97, 0xDB, 0x04, 0xEE, 0x43, 0xFF, 0xAC, 0x0F, 0x75, 0x23, 0x2F, 0x33, 0x9D, 0x3B, 0xBF, 0x3F, /* Pan: 0 */
         0x03, 0xBF, 0xF8, 0xC4, 0x47, 0xCE, 0x21, 0xDD, 0xA5, 0xEF, 0x81, 0x01, 0x48, 0x10, 0x0C, 0x23, 0x82, 0x33, 0xF0, 0x3F, 0xCC, 0x43, /* Pan: 12 */
         0xCE, 0xC2, 0x81, 0xC9, 0x51, 0xD2, 0xFD, 0xDF, 0x75, 0xF0, 0x66, 0x02, 0xED, 0x10, 0xA7, 0x20, 0xD8, 0x30, 0x90, 0x3D, 0x2E, 0x41, /* Pan: 24 */
         0x63, 0xCA, 0xA3, 0xD0, 0x86, 0xD8, 0x33, 0xE4, 0xDD, 0xF1, 0x4D, 0x02, 0xC4, 0x10, 0xD5, 0x1D, 0x43, 0x2B, 0x8C, 0x32, 0x65, 0x3D, /* Pan: 36 */
         0xC8, 0xD3, 0x50, 0xD9, 0x15, 0xE0, 0x23, 0xE9, 0x7E, 0xF3, 0x1C, 0x01, 0x00, 0x10, 0xEB, 0x1B, 0xF8, 0x23, 0xEA, 0x27, 0xC4, 0x37, /* Pan: 48 */
         0x6D, 0xDD, 0x33, 0xE1, 0x06, 0xE6, 0xA2, 0xEC, 0x9D, 0xF4, 0x7B, 0xFF, 0x00, 0x0D, 0x6D, 0x17, 0x2B, 0x1B, 0x56, 0x26, 0xFB, 0x2A  /* Pan: 60 */
};

const uint8_t phNxpUciHal_pdoa_offset_calib_ch_5[] = {
   /* Over All Length */ (4 + 0x0A),
   /* Set Calib */ 0x2F, 0x21,
   /* Length */ 0x00, 0x0A,
   /* Channel */ AD_CALIB_CN(5),
   /* PDOA Offset */ AD_CALIB_CMD_PDOA_OFFSET,
   1 + 3*AD_N_PAIR_ENTRIES(2),
   /* N Entries */ AD_N_PAIR_ENTRIES(2),
   AD_AP_ID(1), AD_CALIB_PDOA_OFFSET(0xDDA3),
   AD_AP_ID(2), AD_CALIB_PDOA_OFFSET(0x41A5)
};

const uint8_t phNxpUciHal_pdoa_offset_calib_ch_9[] = {
   /* Over All Length */ (4 + 0x0A),
   /* Set Calib */ 0x2F, 0x21,
   /* Length */ 0x00, 0x0A,
   /* Channel */ AD_CALIB_CN(9),
   /* PDOA Offset */ AD_CALIB_CMD_PDOA_OFFSET,
   1 + 3*AD_N_PAIR_ENTRIES(2),
   /* N Entries */ AD_N_PAIR_ENTRIES(2),
   AD_AP_ID(1), AD_CALIB_PDOA_OFFSET(0xD8E7),
   AD_AP_ID(2), AD_CALIB_PDOA_OFFSET(0x484E)
};

const uint8_t phNxpUciHal_aoa_threshold_pdoa_calib_ch_5[] = {
   /* Over All Length */ (4 + 0x0A),
   /* Set Calib */ 0x2F, 0x21,
   /* Length */ 0x00, 0x0A,
   /* Channel */ AD_CALIB_CN(5),
   /* PDOA Offset */ AD_CALIB_CMD_AOA_THRESHOLD_PDOA,
   1 + 3*AD_N_PAIR_ENTRIES(2),
   /* N Entries */ AD_N_PAIR_ENTRIES(2),
   AD_AP_ID(1), AD_CALIB_THRESHOLD_PDOA(0x37A2),
   AD_AP_ID(2), AD_CALIB_THRESHOLD_PDOA(0xE7A6)
};

const uint8_t phNxpUciHal_aoa_threshold_pdoa_calib_ch_9[] = {
   /* Over All Length */ (4 + 0x0A),
   /* Set Calib */ 0x2F, 0x21,
   /* Length */ 0x00, 0x0A,
   /* Channel */ AD_CALIB_CN(9),
   /* PDOA Offset */ AD_CALIB_CMD_AOA_THRESHOLD_PDOA,
   1 + 3*AD_N_PAIR_ENTRIES(2),
   /* N Entries */ AD_N_PAIR_ENTRIES(2),
   AD_AP_ID(1), AD_CALIB_THRESHOLD_PDOA(0x32E6),
   AD_AP_ID(2), AD_CALIB_THRESHOLD_PDOA(0xEE4F)
};

/* clang-format on */

const uint8_t phNxpUciHal_NXPCoreConfig1[] = {0x00};

const uint8_t phNxpUciHal_NXPCoreConfig2[] = {0x00};

const uint8_t phNxpUciHal_NXPCoreConfig3[] = {0x00};

const uint8_t phNxpUciHal_NXPCoreConfig4[] = {0x00};

const uint8_t phNxpUciHal_NXPCoreConfig5[] = {0x00};

const uint8_t phNxpUciHal_NXPCoreConfig6[] = {0x00};

const uint8_t phNxpUciHal_NXPCoreConfig7[] = {0x00};

const uint8_t phNxpUciHal_NXPCoreConfig8[] = {0x00};

const uint8_t phNxpUciHal_NXPCoreConfig9[] = {0x00};

const uint8_t phNxpUciHal_NXPCoreConfig10[] = {0x00};

const NxpParam_t phNxpUciHal_NXPConfig[] = {
    /*
     *  Ranging session period: which means, it is the duration of one 1:N
     session and the interval before start of next 1:N session. (1:N ranging
     period + interval between two consecutive  1:N cycles)
        UWB_RANG_SESSION_INTERVAL= (UWB_RANG_CYCLE_INTERVAL * No_of_anchors) +
     IDLE_BEFORE_START_OF_NEXT_1_N Value is in milliseconds This config is valid
     only in 1:N ranging session
     * */
    {UWB_RANG_SESSION_INTERVAL, TYPE_VAL, CONFIG_VAL 2000},
    /*
     *  Application session timeout: How log ranging shall continue.
        value is in milliseconds
        0 value: MW shall configure the value which is passed from application
        Non zero value: MW shall configure timeout with this config value
     provided here
     * */
    {UWB_APP_SESSION_TIMEOUT, TYPE_VAL, CONFIG_VAL 3600000},
    /*
     *  Ranging cycle interval: intreval between two consecutive SS/DS-TWR
     ranging cycle value is in milliseconds 0 value: MW shall configure the
     value which is passed from application Non zero value: MW shall configure
     interval with this config value provided here
     * */
    {UWB_RANG_CYCLE_INTERVAL, TYPE_VAL, CONFIG_VAL 200},
    /*
     *
     *  Timeout value in milliseconds for UWB standby mode.
        The range is between 5000 msec to 20000 msec and zero is to disable
     * */
    {UWB_STANDBY_TIMEOUT_VALUE, TYPE_VAL, CONFIG_VAL 0x00},
    /*
    *FW log level for each above module
     Logging Level Error            0x0001
     Logging Level Warning          0x0002
     Logging Level Timestamp        0x0004
     Logging Level Sequence Number  0x0008
     Logging Level Info-1           0x0010
     Logging Level Info-2           0x0020
     Logging Level Info-3           0x0040
     * */
    {UWB_SET_FW_LOG_LEVEL, TYPE_VAL, CONFIG_VAL 0x003},
    /*
     * Enable/disable to dump FW binary log for different Modules as below
       0x00 for disable the binary log
       Secure Thread      0x01
       Secure ISR         0x02
       Non-Secure ISR     0x04
       Shell Thread       0x08
       PHY Thread         0x10
       Ranging Thread     0x20
     * */
    {UWB_FW_LOG_THREAD_ID, TYPE_VAL, CONFIG_VAL 0x00},
    /*
     * Ranging feature:  Single Sided Two Way Ranging or Double Sided Two Way
     Ranging SS-TWR =0x00 DS-TWR =0x01
     */
    {UWB_MW_RANGING_FEATURE, TYPE_VAL, CONFIG_VAL 0x01},
    /*Board Varaints are defined below:
    BOARD_VARIANT_NXPREF    0x01
    BOARD_VARIANT_CUSTREF1  0x2A
    BOARD_VARIANT_CUSTREF2  0x2B
    BOARD_VARIANT_RHODES    0x73*/
    {UWB_BOARD_VARIANT_CONFIG, TYPE_VAL, CONFIG_VAL 0x73},
    /*
     * # Board Variant version
     * */
    {UWB_BOARD_VARIANT_VERSION, TYPE_VAL, CONFIG_VAL UWB_BOARD_VERSION},
    {UWB_CORE_CONFIG_PARAM, TYPE_DATA, phNxpUciHal_core_configs},
    /* Core config antennae defines*/
    {UWB_CORE_ANTENNAE_DEFINES, TYPE_DATA, phNxpUciHal_core_antennadefs},
    {UWB_RX_ANTENNAE_DELAY_CALIB_CH5, TYPE_DATA, phNxpUciHal_rx_antennae_delay_calib_channel5},
    {UWB_RX_ANTENNAE_DELAY_CALIB_CH6, TYPE_DATA, phNxpUciHal_rx_antennae_delay_calib_channel6},
    {UWB_RX_ANTENNAE_DELAY_CALIB_CH8, TYPE_DATA, phNxpUciHal_rx_antennae_delay_calib_channel8},
    {UWB_RX_ANTENNAE_DELAY_CALIB_CH9, TYPE_DATA, phNxpUciHal_rx_antennae_delay_calib_channel9},

    /*
     * Note: If the size of data is greater than 255 bytes, TYPE_EXTENDED_DATA has to be used.
     * TYPE_DATA must only be used when size of array is less than 255 bytes
     *
     * Example if phNxpUciHal_rx_pair_1_ch_5_pdoa_calib data is more than 255 bytes
     * {UWB_AOA_CONFIG_PDOA_CALIB_RXPAIR1_CH5, TYPE_EXTENDED_DATA, phNxpUciHal_rx_pair_1_ch_5_pdoa_calib},
     */
    {UWB_AOA_CONFIG_PDOA_CALIB_RXPAIR1_CH5, TYPE_DATA, phNxpUciHal_rx_pair_1_ch_5_pdoa_calib},
    {UWB_AOA_CONFIG_PDOA_CALIB_RXPAIR1_CH9, TYPE_DATA, phNxpUciHal_rx_pair_1_ch_9_pdoa_calib},
    {UWB_AOA_CONFIG_PDOA_CALIB_RXPAIR2_CH5, TYPE_DATA, phNxpUciHal_rx_pair_2_ch_5_pdoa_calib},
    {UWB_AOA_CONFIG_PDOA_CALIB_RXPAIR2_CH9, TYPE_DATA, phNxpUciHal_rx_pair_2_ch_9_pdoa_calib},
    {UWB_AOA_CONFIG_PDOA_OFFSET_CH5, TYPE_DATA, phNxpUciHal_pdoa_offset_calib_ch_5},
    {UWB_AOA_CONFIG_PDOA_OFFSET_CH9, TYPE_DATA, phNxpUciHal_pdoa_offset_calib_ch_9},
    {UWB_AOA_CONFIG_THRESHOLD_PDOA_CH5, TYPE_DATA, phNxpUciHal_aoa_threshold_pdoa_calib_ch_5},
    {UWB_AOA_CONFIG_THRESHOLD_PDOA_CH9, TYPE_DATA, phNxpUciHal_aoa_threshold_pdoa_calib_ch_9},
    {UWB_AOA_CONFIG_BLOCK_COUNT, TYPE_VAL, CONFIG_VAL 8},
    /* Timeout for Firmware to enter DPD mode
     * Note: value set for UWB_DPD_ENTRY_TIMEOUT shall be in MilliSeconds.
     * Min : 100ms
     * Max : 2000ms */
    {UWB_DPD_ENTRY_TIMEOUT, TYPE_VAL, CONFIG_VAL 500},
    /* 0x00 = FIRA generic notifications (Default)
     * 0x01 = Vendor extended notifications
     * UWBS shall send any proprietary information in any response/notification
     * if NXP_EXTENDED_NTF_CONFIG is set 0x01 */
    {UWB_NXP_EXTENDED_NTF_CONFIG, TYPE_VAL, CONFIG_VAL 0x01},
    /* Firmware Low Power Mode
     * if UWB_LOW_POWER_MODE is 0, Firmware is Configured in non Low Power Mode
     * if UWB_LOW_POWER_MODE in 1, Firmware is Configured with Low Power Mode */
    {UWB_LOW_POWER_MODE, TYPE_VAL, CONFIG_VAL 0x01},

    {UWB_NXP_CORE_CONFIG_BLOCK_1, TYPE_DATA, phNxpUciHal_NXPCoreConfig1},
    {UWB_NXP_CORE_CONFIG_BLOCK_2, TYPE_DATA, phNxpUciHal_NXPCoreConfig2},
    {UWB_NXP_CORE_CONFIG_BLOCK_3, TYPE_DATA, phNxpUciHal_NXPCoreConfig3},
    {UWB_NXP_CORE_CONFIG_BLOCK_4, TYPE_DATA, phNxpUciHal_NXPCoreConfig4},
    {UWB_NXP_CORE_CONFIG_BLOCK_5, TYPE_DATA, phNxpUciHal_NXPCoreConfig5},
    {UWB_NXP_CORE_CONFIG_BLOCK_6, TYPE_DATA, phNxpUciHal_NXPCoreConfig6},
    {UWB_NXP_CORE_CONFIG_BLOCK_7, TYPE_DATA, phNxpUciHal_NXPCoreConfig7},
    {UWB_NXP_CORE_CONFIG_BLOCK_8, TYPE_DATA, phNxpUciHal_NXPCoreConfig8},
    {UWB_NXP_CORE_CONFIG_BLOCK_9, TYPE_DATA, phNxpUciHal_NXPCoreConfig9},
    {UWB_NXP_CORE_CONFIG_BLOCK_10, TYPE_DATA, phNxpUciHal_NXPCoreConfig10},

    /* Number of UWB_NXP_CORE_CONFIG_BLOCKS available in the config file */
    {UWB_NXP_CORE_CONFIG_BLOCK_COUNT, TYPE_VAL, CONFIG_VAL 10}};

#endif //_UWB_DEVICECONFIG_RV4_SR1XX_H_
